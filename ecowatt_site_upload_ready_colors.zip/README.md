# ECOWATT – Upload Ready (video héroe + galería 18 + partners + íconos)

Rellená los **placeholders vacíos** con tus archivos reales:

- Héroe:
  - Video → `assets/video/hero-ecowatt.mp4`
  - Póster → `assets/img/hero/hero-ecowatt.jpg`
- Galería (18): `assets/img/gallery/galeria_01.jpg` … `galeria_18.jpg`
- Partners: `assets/img/partners/fuchs.svg`, `2g.svg`, `aqana.svg`, `daga.svg`, `airclean.png` (PNG).
- Íconos Soluciones/Tecnologías (en raíz): `gota-blue (2).svg`, `cloaca-blue (2).svg`, `fabrica-blue (2).svg`, `aire-blue (2).svg`, `agitador-blue (2).svg`

## Publicación
- GitHub Pages → Settings → Pages → Deploy from a branch → `main` → `/ (root)`
- Netlify → Build command vacío; Publish directory `/`